
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

 
public class FilterPro extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws IOException {
    	primaryStage.setTitle("Filter Pro");	// set application title as Filter Pro
    	    
        
        Button btn1 = new Button();   			// Create Button
        btn1.setText("Black and White");		// Button name
        
        Button btn2 = new Button();      
        btn2.setText("Yellow");
        
        Button btn3 = new Button();
        btn3.setText("Magenta");
        
        Button btn4 = new Button();
        btn4.setText("Cyan");
        
        Button btn5 = new Button();
        btn5.setText("Negative");
        
        Button btn6 = new Button();
        btn6.setText("Yellow Noise");
        
        btn6.setOnAction(new EventHandler<ActionEvent>(){
        	public void handle(ActionEvent Event){
        		JFileChooser i = new JFileChooser();	// choose file
        	    i.showDialog(null,"Please Select the File");
        	    i.setVisible(true);
        	    
        	    File filename = i.getSelectedFile();  // gets selected file
        	BufferedImage img = null;
			try {
				img = ImageIO.read(filename);		// reads image of the file you chose
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        		
        	    int width = img.getWidth();	
        	    int height = img.getHeight();
        		
        	    for(int y = 0; y < height; y++){		// goes through every pixel vertically
        	    	for (int x = 0; x < width; x++){	// goes through every pixel horizontally
        	    		int v = img.getRGB(x,y);
        	    		
        	    		int alpha = (v>>24) & 0xff; //  & 0xff is getting one of the color components
        	    		int red = (v>>16) & 0xff;		// goes through bits of RGB
        	    		int green = (v>>8) & 0xff;
        	    		int blue = v & 0xff;
        	    		
        	    		int avg = (red+ green + blue) / 3 ; // average
        	    		
        	    		int ran = (int) red * green - avg;		// random replacer
        	    		
        	    		v = (alpha<<24) | (ran <<16) | (ran <<8) | ran; // replace RGB bits (idk)
        	    		
        	    		img.setRGB(x, y, v);						// Set the new img RGB
        	    	}
        	    }
        	  
        	    String sb = ".jpg";								// adds new string .jpg
        	    File selectedFile = new File(filename + sb);	// adds .jpg at the end of your file name
        	    try {
					ImageIO.write(img, "jpg", selectedFile);	//writes the image as (image).jpg
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	  
        	    System.out.println("File has been replaced");		// This wont be used in the actual application just a tester.
        	}
        });
        
       btn5.setOnAction(new EventHandler<ActionEvent>(){
    	   public void handle(ActionEvent Event){
    		   JFileChooser i = new JFileChooser();
    		    i.showDialog(null,"Please Select the File");
    		    i.setVisible(true);
    		    
    		    File filename = i.getSelectedFile();
    	    BufferedImage img = null;
			try {
				img = ImageIO.read(filename);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    			
    		    int width = img.getWidth();
    		    int height = img.getHeight();
    			
    		    for(int y = 0; y < height; y++){
    		    	for (int x = 0; x < width; x++){
    		    		int v = img.getRGB(x,y);
    		    		
    		    		int alpha = (v>>24) & 0xff; //  & 0xff is getting one of the color components
    		    		int red = (v>>16) & 0xff;
    		    		int green = (v>>8) & 0xff;
    		    		int blue = v & 0xff;
    		    		
    		    		int avg = (red+ green + blue) / 3 ; // average
    		    		
    		    		int neg = (int) 255 - avg;
    		    		
    		    		v = (alpha<<24) | (neg <<16) | (neg <<8) | neg; // replace RGB (negative color)
    		    	
    		    		img.setRGB(x, y, v);
    		    	}
    		    }
    		    //filename = new File("C:\\Users\\JVPas\\Pictures\\Saved Pictures\\output.jpg");
    		    String sb = ".jpg";
    		    File selectedFile = new File(filename + sb);
    		    try {
					ImageIO.write(img, "jpg", selectedFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		    System.out.println("File has been replaced");
    	   }
       });
   
        btn4.setOnAction(new EventHandler<ActionEvent>(){
        	public void handle(ActionEvent event){
        		JFileChooser i = new JFileChooser();
        	    i.showDialog(null,"Please Select the File");
        	    i.setVisible(true);
        	    
        	    File filename = i.getSelectedFile();
            BufferedImage img = null;
			try {
				img = ImageIO.read(filename);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        		
        	    int width = img.getWidth();
        	    int height = img.getHeight();
        		
        	    for(int y = 0; y < height; y++){
        	    	for (int x = 0; x < width; x++){
        	    		int v = img.getRGB(x,y);
        	    		
        	    		int alpha = (v>>24) & 0xff; //  & 0xff is getting one of the color components
        	    		int red = (v>>16) & 0xff;
        	    		int green = (v>>8) & 0xff;
        	    		int blue = v & 0xff;
        	    		
        	    		int avg = (red+ green + blue) / 3 ; // average
        	    		
        	    		v = (alpha<<24) | (0 <<16) | (avg <<8) | avg; // replace RGB (cyan)
        	    		
        	    		img.setRGB(x, y, v);
        	    	}
        	    }
        	    //filename = new File("C:\\Users\\JVPas\\Pictures\\Saved Pictures\\output.jpg");
        	    String sb = ".jpg";
        	    File selectedFile = new File(filename + sb);
        	    try {
					ImageIO.write(img, "jpg", selectedFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	    System.out.println("File has been replaced");
        	}
        });
    
        btn3.setOnAction(new EventHandler<ActionEvent>(){
        	public void handle(ActionEvent event){
        		JFileChooser i = new JFileChooser();
        	    i.showDialog(null,"Please Select the File");
        	    i.setVisible(true);
        	    
        	    File filename = i.getSelectedFile();
            BufferedImage img = null;
			try {
				img = ImageIO.read(filename);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        		
        	    int width = img.getWidth();
        	    int height = img.getHeight();
        		
        	    for(int y = 0; y < height; y++){
        	    	for (int x = 0; x < width; x++){
        	    		int v = img.getRGB(x,y);
        	    		
        	    		int alpha = (v>>24) & 0xff; //  & 0xff is getting one of the color components
        	    		int red = (v>>16) & 0xff;
        	    		int green = (v>>8) & 0xff;
        	    		int blue = v & 0xff;
        	    		
        	    		int avg = (red+ green + blue) / 3 ; // average
        	    		
        	    		v = (alpha<<24) | (avg <<16) | (0 <<8) | avg; // replace RGB (Magenta)
        	    		
        	    		img.setRGB(x, y, v);
        	    	}
        	    }
        	    //filename = new File("C:\\Users\\JVPas\\Pictures\\Saved Pictures\\output.jpg");
        	    String sb = ".jpg";
        	    File selectedFile = new File(filename + sb);
        	    try {
					ImageIO.write(img, "jpg", selectedFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	    System.out.println("File has been replaced");
        	}
        });
      
        btn2.setOnAction(new EventHandler<ActionEvent>(){
        	
        	public void handle(ActionEvent event) {
        		
        		JFileChooser i = new JFileChooser();
        	    i.showDialog(null,"Please Select the File");
        	    i.setVisible(true);
        	    
        	    File filename = i.getSelectedFile();
            BufferedImage img = null;
			try {
				img = ImageIO.read(filename);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        		
        	    int width = img.getWidth();
        	    int height = img.getHeight();
        		
        	    for(int y = 0; y < height; y++){
        	    	for (int x = 0; x < width; x++){
        	    		int v = img.getRGB(x,y);
        	    		
        	    		int alpha = (v>>24) & 0xff; //  & 0xff is getting one of the color components
        	    		int red = (v>>16) & 0xff;
        	    		int green = (v>>8) & 0xff;
        	    		int blue = v & 0xff;
        	    		
        	    		int avg = (red+ green + blue) / 3 ; // average
        	    		
        	    		v = (alpha<<24) | (avg <<16) | (avg <<8) | 0; // replace RGB (yellow)
        	    		
        	    		img.setRGB(x, y, v);
        	    	}
        	    }
        	    //filename = new File("C:\\Users\\JVPas\\Pictures\\Saved Pictures\\output.jpg");
        	    String sb = ".jpg";
        	    File selectedFile = new File(filename + sb);
        	    try {
					ImageIO.write(img, "jpg", selectedFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	    System.out.println("File has been replaced");
        		
        	}
        
    });
      
        btn1.setOnAction(new EventHandler<ActionEvent>(){

      
 
            @Override
            public void handle(ActionEvent event) {
            	JFileChooser i = new JFileChooser();
        	    i.showDialog(null,"Please Select the File");
        	    i.setVisible(true);
        	    
        	    File filename = i.getSelectedFile();
            BufferedImage img = null;
			
				try {
					img = ImageIO.read(filename);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        		
        	    int width = img.getWidth();
        	    int height = img.getHeight();
        		
        	    for(int y = 0; y < height; y++){
        	    	for (int x = 0; x < width; x++){
        	    		int v = img.getRGB(x,y);
        	    		
        	    		int alpha = (v>>24) & 0xff; //  & 0xff is getting one of the color components
        	    		int red = (v>>16) & 0xff;
        	    		int green = (v>>8) & 0xff;
        	    		int blue = v & 0xff;
        	    		
        	    		int avg = (red+ green + blue) / 3; // average
        	    		
        	    		v = (alpha<<24) | (avg<<16) | (avg<<8) | avg; // replace RGB (black and white)
        	    		
        	    		img.setRGB(x, y, v);
        	    	}
        	    }
        	    //filename = new File("C:\\Users\\JVPas\\Pictures\\Saved Pictures\\output.jpg");
        	    String sb = ".jpg";
        	    File selectedFile = new File(filename + sb);
        	    try {
					ImageIO.write(img, "jpg", selectedFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	    System.out.println("File has been replaced");
            }
        });
        
        StackPane root = new StackPane();
        
        Text t = new Text("Filter Pro");	//Adding text in my scene
        t.setFont(Font.font("Impact", FontWeight.BOLD, FontPosture.REGULAR, 50));  //Change font
        t.setFill(Color.RED);				// Change color of font
        t.setTranslateX(0);					// moving the x value of the text
        t.setTranslateY(-130);				// moving Y value of Text
        root.getChildren().add(t);			// Adding the text to scene
        
        btn1.setTranslateX(0);
        btn1.setTranslateY(-40);
        root.getChildren().add(btn1);
        btn2.setTranslateX(0);
        btn2.setTranslateY(0);
        root.getChildren().add(btn2);
        btn3.setTranslateX(0);
        btn3.setTranslateY(40);
        root.getChildren().add(btn3);
        btn4.setTranslateX(0);
        btn4.setTranslateY(80);
        root.getChildren().add(btn4);
        btn5.setTranslateX(0);
        btn5.setTranslateY(120);
        root.getChildren().add(btn5);
        btn6.setTranslateX(0);
        btn6.setTranslateY(160);
        root.getChildren().add(btn6);
        root.setStyle("-fx-background-color: Black");	// Changing background color
        
        primaryStage.setScene(new Scene(root, 250, 450)); //Setting width and height of scene
       // root.getChildren().add(btn2);
        primaryStage.show();
        primaryStage.setResizable(false);				// Setting application to not being resizable
    }
    
   
     	    }